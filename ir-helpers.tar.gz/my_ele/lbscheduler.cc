#include <click/config.h>
#include "lbscheduler.hh"
#include <clicknet/ether.h>
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include <clicknet/udp.h>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/router.hh>
CLICK_DECLS

LBScheduler::LBScheduler()
{
}

LBScheduler::~LBScheduler()
{
}

void *
LBScheduler::cast(const char *n)
{
    return nullptr;
}

int
LBScheduler::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
LBScheduler::push(int port, Packet *p_in)
{
    WritablePacket *p = p_in->uniqueify();

    click_ether *ethh = p->ether_header();
    click_ip *iph = p->ip_header();
    if (ethh->ether_type == ntohs(ETHERTYPE_IP) && iph->ip_p == IP_PROTO_TCP) {
        auto* dst_ip = _addr_map.findp(_cnt);
        if (dst_ip) {
            iph->ip_dst.s_addr = htonl(*dst_ip);
            checked_output_push(0, p);
        } else {
            p->kill();
        }
    } else {
        p->kill();
    }
    _cnt = (_cnt + 1) % _num_dst;
}

void
LBScheduler::add_handlers()
{
}

CLICK_ENDDECLS
EXPORT_ELEMENT(LBScheduler)
