/*
 * etherswitch.{cc,hh} -- learning, forwarding Ethernet bridge
 * John Jannotti
 *
 * Copyright (c) 1999-2000 Massachusetts Institute of Technology
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, subject to the conditions
 * listed in the Click LICENSE file. These conditions include: you must
 * preserve this copyright notice, and you cannot mention the copyright
 * holders in advertising related to the Software without their permission.
 * The Software is provided WITHOUT ANY WARRANTY, EXPRESS OR IMPLIED. This
 * notice is a summary of the Click LICENSE file; the license in that file is
 * legally binding.
 */

#include <click/config.h>
#include "etherswitchmod.hh"
#include <clicknet/ether.h>
#include <click/etheraddress.hh>
#include <click/glue.hh>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
CLICK_DECLS

EtherSwitchMod::EtherSwitchMod()
{
}

EtherSwitchMod::~EtherSwitchMod()
{
    _table.clear();
}

int
EtherSwitchMod::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
EtherSwitchMod::broadcast(int source, Packet *p)
{
  int n = noutputs();
  assert((unsigned) source < (unsigned) n);
  for (int i = n - 1; i >=0 ; i--) {
    if (i != source) {
      Packet *pp = p->clone();
      checked_output_push(i, pp);
    }
  }
  p->kill();
}

void
EtherSwitchMod::push(int source, Packet *p)
{
    const click_ether* e = p->ether_header();
    int outport = -1;		// Broadcast

	// Set outport if dst is unicast, we have info about it, and the
	// info is still valid.
	EtherAddress dst(e->ether_dhost);
    AddrInfo *dst_info = _table.findp(dst);

    if (dst_info) {
        outport = dst_info->port;
        checked_output_push(outport, p);
    } else {
        broadcast(source, p);
    }
	_table.insert(EtherAddress(e->ether_shost), AddrInfo(source));
}

String
EtherSwitchMod::reader(Element* f, void *thunk)
{
    EtherSwitchMod* sw = (EtherSwitchMod*)f;
    switch ((intptr_t) thunk) {
    case 0: {
	StringAccum sa;
	for (Table::iterator iter = sw->_table.begin(); iter.live(); iter++)
	    sa << iter.key() << ' ' << iter.value().port << '\n';
	return sa.take_string();
    }
    case 1:
	return String(0);
    default:
	return String();
    }
}

int
EtherSwitchMod::writer(const String &s, Element *e, void *, ErrorHandler *errh)
{
    return 0;
}

void
EtherSwitchMod::add_handlers()
{
    add_read_handler("table", reader, 0);
    add_read_handler("timeout", reader, 1);
    add_write_handler("timeout", writer, 0);
}

EXPORT_ELEMENT(EtherSwitchMod)
CLICK_ENDDECLS
