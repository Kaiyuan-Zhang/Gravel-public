#include <click/config.h>
#include "lbstorage.hh"
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include <clicknet/udp.h>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/router.hh>
CLICK_DECLS

LBStorage::LBStorage()
{
}

LBStorage::~LBStorage()
{
}

void *
LBStorage::cast(const char *n)
{
    return nullptr;
}

int
LBStorage::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
LBStorage::push(int port, Packet *p_in)
{
    WritablePacket *p = p_in->uniqueify();

    click_ip *iph = p->ip_header();
    uint16_t *trans_h = (uint16_t *)p->transport_header();

    uint16_t src_port = ntohs(trans_h[0]);

    struct LBFlowId flow_id;
    flow_id.ip_addr = ntohl(iph->ip_src.s_addr);
    flow_id.port = src_port;

    auto* dst_addr = _decisions.findp(flow_id);
    if (port == 0) {
        if (dst_addr) {
            iph->ip_dst.s_addr = htonl(*dst_addr);
            _timestamps.insert(flow_id, _curr_time);
            checked_output_push(0, p);
        } else {
            checked_output_push(1, p);
        }
    } else {
        uint32_t dst_addr = ntohl(iph->ip_dst.s_addr);
        _decisions.insert(flow_id, dst_addr);
        _timestamps.insert(flow_id, _curr_time);
        checked_output_push(0, p);
    }
}

void
LBStorage::add_handlers()
{
}

CLICK_ENDDECLS
EXPORT_ELEMENT(LBStorage)
