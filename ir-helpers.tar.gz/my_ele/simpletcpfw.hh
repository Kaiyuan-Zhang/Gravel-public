#ifndef CLICK_SIMPLETCPFW_HH
#define CLICK_SIMPLETCPFW_HH
#include <click/element.hh>
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include "click/hashmap.hh"
#include "click/ipflowid.hh"
CLICK_DECLS

class SimpleTCPFW : public Element { public:
    SimpleTCPFW() CLICK_COLD;
    ~SimpleTCPFW() CLICK_COLD;

    const char *class_name() const		{ return "SimpleTCPFW"; }
    void *cast(const char *);

    int configure(Vector<String> &, ErrorHandler *) CLICK_COLD;
    
    void push(int, Packet *);

    void add_handlers() CLICK_COLD;

  private:
    HashMap<IPFlowID, uint8_t> _flows;
};

CLICK_ENDDECLS
#endif
