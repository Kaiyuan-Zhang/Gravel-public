
#ifndef CLICK_SIMPLETCPFILTER_HH
#define CLICK_SIMPLETCPFILTER_HH
#include <click/element.hh>
#include <clicknet/ip.h>
#include "click/hashmap.hh"
CLICK_DECLS

class SimpleTCPFilter : public Element { public:
    SimpleTCPFilter() CLICK_COLD;
    ~SimpleTCPFilter() CLICK_COLD;

    const char *class_name() const		{ return "SimpleTCPFilter"; }
    void *cast(const char *);

    int configure(Vector<String> &, ErrorHandler *) CLICK_COLD;
    
    void push(int, Packet *);

    void add_handlers() CLICK_COLD;
private:
    // added to make sure verifier can find this class, otherwise it maybe merged into base
    uint32_t dummy;
};

CLICK_ENDDECLS
#endif
