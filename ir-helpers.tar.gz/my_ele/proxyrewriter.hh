#ifndef CLICK_PROXYREWRITER_HH
#define CLICK_PROXYREWRITER_HH
#include <click/element.hh>
#include <clicknet/ip.h>
#include "click/hashmap.hh"
#include "click/ipflowid.hh"
CLICK_DECLS

class ProxyRewriter : public Element { public:
    ProxyRewriter() CLICK_COLD;
    ~ProxyRewriter() CLICK_COLD;

    struct IPRewriteEntry {
        uint32_t saddr;
        uint32_t daddr;
        uint16_t sport;
        uint16_t dport;
        int outport;
    } __attribute__((__packed__));

    const char *class_name() const		{ return "ProxyRewriter"; }
    void *cast(const char *);

    int configure(Vector<String> &, ErrorHandler *) CLICK_COLD;
    
    void push(int, Packet *);

    void add_handlers() CLICK_COLD;

  private:
    HashMap<IPFlowID, IPRewriteEntry> _udp_map;
    HashMap<IPFlowID, IPRewriteEntry> _tcp_map;
};

CLICK_ENDDECLS
#endif
