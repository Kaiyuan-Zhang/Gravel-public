#include <click/config.h>
#include "simpletcpfilter.hh"
#include <clicknet/ether.h>
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include <clicknet/udp.h>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/router.hh>
CLICK_DECLS

SimpleTCPFilter::SimpleTCPFilter()
{
}

SimpleTCPFilter::~SimpleTCPFilter()
{
}

void *
SimpleTCPFilter::cast(const char *n)
{
    return nullptr;
}

int
SimpleTCPFilter::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
SimpleTCPFilter::push(int port, Packet *p)
{
    const click_ip *iph = p->ip_header();
    if (iph->ip_p == IP_PROTO_TCP) {
        checked_output_push(0, p);
    } else {
        p->kill();
    }
}

void
SimpleTCPFilter::add_handlers()
{
}

CLICK_ENDDECLS
EXPORT_ELEMENT(SimpleTCPFilter)
