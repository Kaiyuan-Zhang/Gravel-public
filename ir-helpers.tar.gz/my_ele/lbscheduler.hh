
#ifndef CLICK_LBSCHEDULER_HH
#define CLICK_LBSCHEDULER_HH
#include <click/element.hh>
#include <clicknet/ip.h>
#include "click/hashmap.hh"
CLICK_DECLS

class LBScheduler : public Element { public:
    LBScheduler() CLICK_COLD;
    ~LBScheduler() CLICK_COLD;

    const char *class_name() const		{ return "LBScheduler"; }
    void *cast(const char *);

    int configure(Vector<String> &, ErrorHandler *) CLICK_COLD;
    
    void push(int, Packet *);

    void add_handlers() CLICK_COLD;

  private:

    HashMap<uint32_t, uint32_t> _addr_map;
    uint32_t _cnt;
    uint32_t _num_dst;
};

CLICK_ENDDECLS
#endif
