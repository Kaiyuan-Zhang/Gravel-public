#include <click/config.h>
#include "proxyrewriter.hh"
#include <clicknet/ether.h>
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include <clicknet/udp.h>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/router.hh>
CLICK_DECLS

ProxyRewriter::ProxyRewriter()
{
}

ProxyRewriter::~ProxyRewriter()
{
}

void *
ProxyRewriter::cast(const char *n)
{
    return nullptr;
}

int
ProxyRewriter::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
ProxyRewriter::push(int port, Packet *p_in)
{
    WritablePacket *p = p_in->uniqueify();
    click_ip *iph = p->ip_header();

    uint16_t *trans_h = (uint16_t *)p->transport_header();

    auto src_addr = ntohl(iph->ip_src.s_addr);
    auto dst_addr = ntohl(iph->ip_dst.s_addr);
    uint16_t src_port = ntohs(trans_h[0]);
    uint16_t dst_port = ntohs(trans_h[1]);

    IPFlowID flow_id(p);

    auto protocol = iph->ip_p;
    if (protocol == IP_PROTO_TCP) {
        auto *m = &_tcp_map;
        auto *rewrite_entry = m->findp(flow_id);
        if (rewrite_entry) {
            iph->ip_src.s_addr = htonl(rewrite_entry->saddr);
            iph->ip_dst.s_addr = htonl(rewrite_entry->daddr);
            trans_h[0] = htons(rewrite_entry->sport);
            trans_h[1] = htons(rewrite_entry->dport);
            checked_output_push(rewrite_entry->outport, p);
        } else {
            uint16_t new_port = 0xabcd;
            IPRewriteEntry entry;
            entry.saddr = 0xc0c0c0c0;
            entry.daddr = 0xa0a0a0a0;
            entry.sport = new_port;
            entry.dport = ntohs(8000);
            entry.outport = 0;
            
            IPFlowID rev_flow;
            rev_flow.set_saddr(entry.daddr);
            rev_flow.set_daddr(entry.saddr);
            rev_flow.set_sport(entry.dport);
            rev_flow.set_dport(entry.sport);

            IPRewriteEntry rev_entry;
            rev_entry.saddr = dst_addr;
            rev_entry.daddr = src_addr;
            rev_entry.sport = dst_port;
            rev_entry.dport = src_port;
            rev_entry.outport = 1;

            auto *rev = m->findp(rev_flow);
            if (!rev) {
                m->insert(flow_id, entry);
                m->insert(rev_flow, rev_entry);
            }

            iph->ip_src.s_addr = htonl(entry.saddr);
            iph->ip_dst.s_addr = htonl(entry.daddr);
            trans_h[0] = htons(entry.sport);
            trans_h[1] = htons(entry.dport);
            checked_output_push(entry.outport, p);
        }
    } else if (protocol == IP_PROTO_UDP) {
        auto* m = &_udp_map;
        auto *rewrite_entry = m->findp(flow_id);
        if (rewrite_entry) {
            iph->ip_src.s_addr = htonl(rewrite_entry->saddr);
            iph->ip_dst.s_addr = htonl(rewrite_entry->daddr);
            trans_h[0] = htons(rewrite_entry->sport);
            trans_h[1] = htons(rewrite_entry->dport);
            checked_output_push(rewrite_entry->outport, p);
        } else {
            uint16_t new_port = 0xabcd;
            IPRewriteEntry entry;
            entry.saddr = 0xc0c0c0c0;
            entry.daddr = 0xa0a0a0a0;
            entry.sport = new_port;
            entry.dport = ntohs(8000);
            entry.outport = 0;
            
            IPFlowID rev_flow;
            rev_flow.set_saddr(entry.daddr);
            rev_flow.set_daddr(entry.saddr);
            rev_flow.set_sport(entry.dport);
            rev_flow.set_dport(entry.sport);

            IPRewriteEntry rev_entry;
            rev_entry.saddr = dst_addr;
            rev_entry.daddr = src_addr;
            rev_entry.sport = dst_port;
            rev_entry.dport = src_port;
            rev_entry.outport = 1;

            auto *rev = m->findp(rev_flow);
            if (!rev) {
                m->insert(flow_id, entry);
                m->insert(rev_flow, rev_entry);
            }

            iph->ip_src.s_addr = htonl(entry.saddr);
            iph->ip_dst.s_addr = htonl(entry.daddr);
            trans_h[0] = htons(entry.sport);
            trans_h[1] = htons(entry.dport);
            checked_output_push(entry.outport, p);
        }
    }
}

void
ProxyRewriter::add_handlers()
{
}

CLICK_ENDDECLS
EXPORT_ELEMENT(ProxyRewriter)
