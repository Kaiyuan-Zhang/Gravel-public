#include <click/config.h>
#include "simpleipfilter.hh"
#include <clicknet/ether.h>
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include <clicknet/udp.h>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/router.hh>
CLICK_DECLS

SimpleIPFilter::SimpleIPFilter()
{
}

SimpleIPFilter::~SimpleIPFilter()
{
}

void *
SimpleIPFilter::cast(const char *n)
{
    return nullptr;
}

int
SimpleIPFilter::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
SimpleIPFilter::push(int port, Packet *p)
{
    const click_ether *ethh = p->ether_header();
    if (ethh->ether_type == ntohs(ETHERTYPE_IP)) {
        checked_output_push(0, p);
    } else {
        p->kill();
    }
}

void
SimpleIPFilter::add_handlers()
{
}

CLICK_ENDDECLS
EXPORT_ELEMENT(SimpleIPFilter)
