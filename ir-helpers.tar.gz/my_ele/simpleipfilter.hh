
#ifndef CLICK_SIMPLEIPFILTER_HH
#define CLICK_SIMPLEIPFILTER_HH
#include <click/element.hh>
#include <clicknet/ip.h>
#include "click/hashmap.hh"
CLICK_DECLS

class SimpleIPFilter : public Element { public:
    SimpleIPFilter() CLICK_COLD;
    ~SimpleIPFilter() CLICK_COLD;

    const char *class_name() const		{ return "SimpleIPFilter"; }
    void *cast(const char *);

    int configure(Vector<String> &, ErrorHandler *) CLICK_COLD;
    
    void push(int, Packet *);

    void add_handlers() CLICK_COLD;

    // added to make sure verifier can find this class, otherwise it maybe merged into base
    uint32_t dummy;
};

CLICK_ENDDECLS
#endif
