
#ifndef CLICK_LBSTORAGE_HH
#define CLICK_LBSTORAGE_HH
#include <click/element.hh>
#include <clicknet/ip.h>
#include "click/hashmap.hh"
CLICK_DECLS

struct LBFlowId {
    uint32_t ip_addr;
    uint16_t port;
    inline hashcode_t hashcode() const {
        return ::hashcode(ip_addr) ^ ::hashcode(port);
    }

    inline bool operator==(const LBFlowId &o) const {
        return (ip_addr == o.ip_addr) && (port == o.port);
    }
} __attribute__((__packed__));

class LBStorage : public Element { public:
    LBStorage() CLICK_COLD;
    ~LBStorage() CLICK_COLD;

    const char *class_name() const		{ return "LBStorage"; }
    void *cast(const char *);

    int configure(Vector<String> &, ErrorHandler *) CLICK_COLD;
    
    void push(int, Packet *);

    void add_handlers() CLICK_COLD;

  private:

    HashMap<LBFlowId, uint32_t> _decisions;
    HashMap<LBFlowId, uint64_t> _timestamps;
    uint64_t _curr_time;
};

CLICK_ENDDECLS
#endif
