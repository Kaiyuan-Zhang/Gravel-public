#include <click/config.h>
#include "simpletcpfw.hh"
#include <clicknet/ether.h>
#include <clicknet/ip.h>
#include <clicknet/tcp.h>
#include <clicknet/udp.h>
#include <click/args.hh>
#include <click/straccum.hh>
#include <click/error.hh>
#include <click/timer.hh>
#include <click/router.hh>
CLICK_DECLS

SimpleTCPFW::SimpleTCPFW()
{
}

SimpleTCPFW::~SimpleTCPFW()
{
}

void *
SimpleTCPFW::cast(const char *n)
{
    return nullptr;
}

int
SimpleTCPFW::configure(Vector<String> &conf, ErrorHandler *errh)
{
    return 0;
}

void
SimpleTCPFW::push(int port, Packet *p)
{
    const click_ip *iph = p->ip_header();

    const uint16_t *trans_h = (const uint16_t *)p->transport_header();

    auto src_addr = ntohl(iph->ip_src.s_addr);
    auto dst_addr = ntohl(iph->ip_dst.s_addr);
    uint16_t src_port = ntohs(trans_h[0]);
    uint16_t dst_port = ntohs(trans_h[1]);

    IPFlowID flow_id(p);
    // flow_id.set_saddr(src_addr);
    // flow_id.set_daddr(dst_addr);
    // flow_id.set_sport(src_port);
    // flow_id.set_dport(dst_port);

    const click_tcp *tcph = (const click_tcp *)trans_h;
    uint8_t flag = tcph->th_flags;
    bool should_remove = false;
    if ((flag & TH_FIN) || (flag & TH_RST)) {
        should_remove = true;
    }
    bool should_add = flag & TH_SYN;
    if (port == 0) {
        // external
        uint8_t *allow = _flows.findp(flow_id);
        if (allow) {
            // if (should_remove) {
            //     _flows.erase(flow_id);
            // }
            checked_output_push(1, p);
        }
    } else {
        // internal
        IPFlowID rev_id;
        rev_id.set_saddr(dst_addr);
        rev_id.set_daddr(src_addr);
        rev_id.set_sport(dst_port);
        rev_id.set_dport(src_port);

        if (should_add) {
            _flows.insert(rev_id, 1);
        } else if (should_remove) {
            _flows.erase(rev_id);
        }
        checked_output_push(0, p);
    }
}

void
SimpleTCPFW::add_handlers()
{
}

CLICK_ENDDECLS
EXPORT_ELEMENT(SimpleTCPFW)
